

#ifndef POFO_COM
#define POFO_COM






/* Specific functions for Tetris */

#define ORDER_LAUNCH_GAME 'B'
#define ORDER_PAUSE		  'C'
#define ORDER_TETRIS	  'D'
#define ORDER_SEND_CONFIG 'E'
void 	SendOrder(unsigned char Order);
void 	PrintMessageFromPofoDuino(void);




/* Librairy for communication with arduino */
#define ORDER_PING_POFODUINO		'A'
void 			Ping  		(void);
void 			InitPofoCom	(void);
void 			SendByte	(unsigned char byte);
unsigned char 	GetByte		(void);
char 			SendBuffer	(unsigned short Len, unsigned char *Buffer);
unsigned short 	GetBuffer	(unsigned char * Buffer);


#endif