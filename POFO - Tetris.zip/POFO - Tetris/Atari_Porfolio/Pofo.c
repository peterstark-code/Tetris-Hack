


#include "pofo_com.h"


 main()
{
	unsigned char Config=0;
	unsigned char Order	=0;
	
	
	InitPofoCom();
		
	printf("wait connection\n");	
	PingPofoDuino();
	
	
	
	printf("################\n");
	printf("1 - Tetris\n");
	printf("2 - Square\n");
	printf("3 - Tetris with Square\n");
	printf("################\n->");
	scanf("%d",&Config);	
	
	SendOrder(ORDER_SEND_CONFIG);
	SendByte(Config);	
	SendOrder(ORDER_LAUNCH_GAME);
	
	PrintMessageFromPofoDuino();   /* message A*/
	PrintMessageFromPofoDuino();   /* message B*/
	PrintMessageFromPofoDuino();   /* message C*/
	PrintMessageFromPofoDuino();   /* message D*/	
	
	
	while(Order!=3)
	{
		printf("################\n");
		printf("1 - pause\n");
		printf("2 - Tetris\n");
		printf("3 - quit\n");
		printf("################\n->");
		fflush();
		scanf("%d",&Order);
		
		switch(Order)
		{
			case 1 :
				SendOrder(ORDER_PAUSE);
			
			break;
			
			
			case 2:
				SendOrder(ORDER_TETRIS);
			
			break;			
			
		}
		
		
	}
	
	
}


