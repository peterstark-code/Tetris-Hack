﻿namespace Pofoduino_V2
{
    partial class Main_Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button_Select_File = new System.Windows.Forms.Button();
            this.TextBox_File = new System.Windows.Forms.TextBox();
            this.ComboBox_SerialPort = new System.Windows.Forms.ComboBox();
            this.Label_Status = new System.Windows.Forms.Label();
            this.Button_Send = new System.Windows.Forms.Button();
            this.ProgressBar_upload = new System.Windows.Forms.ProgressBar();
            this.Label_Percent = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Button_Select_File
            // 
            this.Button_Select_File.Location = new System.Drawing.Point(62, 97);
            this.Button_Select_File.Name = "Button_Select_File";
            this.Button_Select_File.Size = new System.Drawing.Size(70, 20);
            this.Button_Select_File.TabIndex = 0;
            this.Button_Select_File.Text = "...";
            this.Button_Select_File.UseVisualStyleBackColor = true;
            this.Button_Select_File.Click += new System.EventHandler(this.Button_Select_File_Click);
            // 
            // TextBox_File
            // 
            this.TextBox_File.Location = new System.Drawing.Point(157, 98);
            this.TextBox_File.Name = "TextBox_File";
            this.TextBox_File.Size = new System.Drawing.Size(253, 20);
            this.TextBox_File.TabIndex = 1;
            // 
            // ComboBox_SerialPort
            // 
            this.ComboBox_SerialPort.FormattingEnabled = true;
            this.ComboBox_SerialPort.Location = new System.Drawing.Point(157, 47);
            this.ComboBox_SerialPort.Name = "ComboBox_SerialPort";
            this.ComboBox_SerialPort.Size = new System.Drawing.Size(253, 21);
            this.ComboBox_SerialPort.TabIndex = 2;
            // 
            // Label_Status
            // 
            this.Label_Status.AutoSize = true;
            this.Label_Status.Location = new System.Drawing.Point(240, 184);
            this.Label_Status.Name = "Label_Status";
            this.Label_Status.Size = new System.Drawing.Size(76, 13);
            this.Label_Status.TabIndex = 4;
            this.Label_Status.Text = "not connected";
            // 
            // Button_Send
            // 
            this.Button_Send.Location = new System.Drawing.Point(62, 148);
            this.Button_Send.Name = "Button_Send";
            this.Button_Send.Size = new System.Drawing.Size(70, 23);
            this.Button_Send.TabIndex = 5;
            this.Button_Send.Text = "send";
            this.Button_Send.UseVisualStyleBackColor = true;
            this.Button_Send.Click += new System.EventHandler(this.Button_Send_Click);
            // 
            // ProgressBar_upload
            // 
            this.ProgressBar_upload.Location = new System.Drawing.Point(157, 148);
            this.ProgressBar_upload.Name = "ProgressBar_upload";
            this.ProgressBar_upload.Size = new System.Drawing.Size(253, 23);
            this.ProgressBar_upload.TabIndex = 6;
            
            // 
            // Label_Percent
            // 
            this.Label_Percent.AutoSize = true;
            this.Label_Percent.Location = new System.Drawing.Point(416, 153);
            this.Label_Percent.Name = "Label_Percent";
            this.Label_Percent.Size = new System.Drawing.Size(21, 13);
            this.Label_Percent.TabIndex = 7;
            this.Label_Percent.Text = "0%";
            // 
            // Main_Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(536, 232);
            this.Controls.Add(this.Label_Percent);
            this.Controls.Add(this.ProgressBar_upload);
            this.Controls.Add(this.Button_Send);
            this.Controls.Add(this.Label_Status);
            this.Controls.Add(this.ComboBox_SerialPort);
            this.Controls.Add(this.TextBox_File);
            this.Controls.Add(this.Button_Select_File);
            this.Name = "Main_Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pofoduino V2";
            this.Load += new System.EventHandler(this.Main_Form_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Button_Select_File;
        private System.Windows.Forms.TextBox TextBox_File;
        private System.Windows.Forms.ComboBox ComboBox_SerialPort;
        private System.Windows.Forms.Label Label_Status;
        private System.Windows.Forms.Button Button_Send;
        private System.Windows.Forms.ProgressBar ProgressBar_upload;
        private System.Windows.Forms.Label Label_Percent;
    }
}

