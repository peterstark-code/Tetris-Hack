


#ifndef My_Defines
#define My_Defines



typedef enum
{
  VERB_QUIET = 0,
  VERB_ERRORS,
  VERB_COUNTER,
  VERB_FLOWCONTROL
} VERBOSITY;





// used for communication with Pofolio , not for file
#define PIN_DATA_INPUT_0  4
#define PIN_DATA_INPUT_1  5
#define PIN_DATA_INPUT_2  6
#define PIN_DATA_INPUT_3  7
#define PIN_DATA_INPUT_CLOCK 8

#define PIN_DATA_OUTPUT_0 9
#define PIN_DATA_OUTPUT_1 10
#define PIN_DATA_OUTPUT_2 11
#define PIN_DATA_OUTPUT_3 12
#define PIN_DATA_OUTPUT_CLOCK 13 


// only used to upload file
#define PIN_INPUT_CLOCK 9   //pin sub D25 pin 12
#define PIN_INPUT_DATA  10  //pin sub D25 pin 13

#define PIN_OUTPUT_CLOCK  5 //pin sub D25 pin 3
#define PIN_OUTPUT_DATA   4 //pin sub D25 pin 2


// pin to launch the transfert file mode
#define PIN_MODE          23 


#define ORDER_PING_POFODUINO      'A'
#define ORDER_LAUNCH_GAME         'B'
#define ORDER_PAUSE               'C'
#define ORDER_TETRIS              'D'
#define ORDER_SEND_CONFIG         'E'

#define CONFIG_TETRIS             1
#define CONFIG_SQUARE             2
#define CONFIG_TETRIS_WITH_SQUARE 3

#define STATUS_RUNNING  0
#define STATUS_PAUSE    1
#define STATUS_NOTHING  2
int CurrentStatus=STATUS_NOTHING;

#endif
